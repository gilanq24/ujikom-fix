-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 14 Mar 2023 pada 10.05
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `buku`
--

CREATE TABLE `buku` (
  `id` int(11) NOT NULL,
  `kode` varchar(225) NOT NULL,
  `kategori` varchar(100) NOT NULL,
  `judul_buku` varchar(100) NOT NULL,
  `jumlah_buku` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `buku`
--

INSERT INTO `buku` (`id`, `kode`, `kategori`, `judul_buku`, `jumlah_buku`) VALUES
(30, 'BK1', 'SEJARAH', 'SOEKARNO', 5),
(31, 'BK2', 'CERITA RAKYAT', 'MALIN KUNDANG', 10),
(32, 'BK3', 'SEJARAH', 'KEMERDEKAAN', 10),
(33, 'BK4', 'NOVEL', 'APA AJA', 10),
(34, 'BK5', 'CERITA RAKYAT', 'SANGKURIANG', 10);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pinjaman`
--

CREATE TABLE `pinjaman` (
  `kode` varchar(10) NOT NULL,
  `nis` int(11) NOT NULL,
  `nama_siswa` varchar(100) NOT NULL,
  `kode_buku` varchar(100) NOT NULL,
  `judul_buku` varchar(100) NOT NULL,
  `tanggal` datetime NOT NULL DEFAULT current_timestamp(),
  `jumlah_pinjam` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data untuk tabel `pinjaman`
--

INSERT INTO `pinjaman` (`kode`, `nis`, `nama_siswa`, `kode_buku`, `judul_buku`, `tanggal`, `jumlah_pinjam`) VALUES
('T-00001', 20211184, 'Putra Gilang Ramadan', 'BK1', 'SOEKARNO', '2023-03-14 15:59:11', 3),
('T-00002', 20211183, 'Jarot', 'BK2', 'MALIN KUNDANG', '2023-03-14 15:59:15', 1),
('T-00003', 20211184, 'Putra Gilang Ramadan', 'BK3', 'KEMERDEKAAN', '2023-03-14 15:59:26', 3),
('T-00004', 20211184, 'Putra Gilang Ramadan', 'BK3', 'KEMERDEKAAN', '2023-03-14 15:59:33', 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa`
--

CREATE TABLE `siswa` (
  `id` int(11) NOT NULL,
  `nis` int(11) NOT NULL,
  `kelas` varchar(100) NOT NULL,
  `nama_siswa` varchar(100) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `kota` varchar(100) NOT NULL,
  `nomor_telepon` varchar(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `siswa`
--

INSERT INTO `siswa` (`id`, `nis`, `kelas`, `nama_siswa`, `alamat`, `kota`, `nomor_telepon`) VALUES
(12, 20211184, 'XII RPL3', 'Putra Gilang Ramadan', 'Kp.Saapan Desa Cipatik', 'Bandung', '08917287288'),
(14, 20211183, 'XII RPL3', 'Jarot', 'Kp.Balakasap Desa Cipatik', 'Jakarta', '0892728726'),
(16, 20211209, 'XII RPL 2', 'Anggara', 'XII RPL 2', 'Bandung', '08972827287'),
(17, 20211206, 'XII RPL 3', 'Yogi', 'XII RPL 3', 'Bandung', '0897262522'),
(18, 20211200, 'XII RPL 6', 'Ramadan', 'XII RPL 6', 'Bandung', '08972625265'),
(19, 20212555, 'Test', 'Test', 'Test', 'Test', '089826262626'),
(20, 20212303, 'XII RPL 3', 'Jamil', 'Kp.Ciwastra', 'Bandung', '0891818171');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_kategori`
--

CREATE TABLE `tb_kategori` (
  `id` int(11) NOT NULL,
  `kode` varchar(25) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tb_kategori`
--

INSERT INTO `tb_kategori` (`id`, `kode`, `nama_kategori`) VALUES
(9, 'SJR', 'SEJARAH'),
(10, 'CRY', 'CERITA RAKYAT'),
(11, 'NVL', 'NOVEL');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(11) NOT NULL,
  `username` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tb_user`
--

INSERT INTO `tb_user` (`id`, `username`, `password`) VALUES
(1, 'Admin', '202cb962ac59075b964b07152d234b70');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pinjaman`
--
ALTER TABLE `pinjaman`
  ADD PRIMARY KEY (`kode`);

--
-- Indeks untuk tabel `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_kategori`
--
ALTER TABLE `tb_kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `buku`
--
ALTER TABLE `buku`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT untuk tabel `siswa`
--
ALTER TABLE `siswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `tb_kategori`
--
ALTER TABLE `tb_kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
